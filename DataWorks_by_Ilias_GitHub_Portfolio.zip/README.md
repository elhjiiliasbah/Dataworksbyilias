# Webshop-verkoopanalyse | DataWorks by Ilias

Portfolio-project in data-analyse en business intelligence.

## Projectbeschrijving
Voor deze analyse is een online-retaildataset onderzocht met Excel. Het doel is om verkoopprestaties, productresultaten en datakwaliteit inzichtelijk te maken.

## Wat is onderzocht?
- Gegevens opgeschoond en datakwaliteit gecontroleerd
- Omzet berekend, inclusief positieve en negatieve transacties
- Omzet per maand en producten geanalyseerd met draaitabellen
- Dashboard met grafieken en KPI's ontwikkeld
- Conclusies en aanbevelingen opgesteld

## Resultaten uit de volledige analyse
| KPI | Bedrag |
|---|---:|
| Positieve omzet | £10.666.684,54 |
| Negatieve omzet | -£918.936,61 |
| Netto-omzet | £9.747.747,93 |

## GitHub-voorbeeldbestand
`Webshop_Analyse_Voorbeeld.xlsx` bevat **500 voorbeeldregels** uit de opgeschoonde gegevens en een overzicht van KPI's uit de volledige analyse.

**Belangrijk:** dit kleine bestand is niet de volledige Excel-analyse. De oorspronkelijke uitgebreide draaitabellen, het interactieve dashboard en alle gegevens zijn wegens de bestandsgrootte niet opgenomen. De KPI's komen uit het volledige bestand en zijn niet berekend op basis van de 500 voorbeeldregels.

## Gebruikte vaardigheden
Excel · Data cleaning · Draaitabellen · KPI's · Data-analyse · Dashboardontwerp

## Auteur
**DataWorks by Ilias** — Data Analytics & Data Engineering
